
package vehiclerentalmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.Expression;

public class addDrivers extends JFrame implements ActionListener {
    
JTextField nameText, ageText,DidText,MidText;
    JComboBox comboBox, comboBox1;
    JButton add, back;
    addDrivers(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,890,490);
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setLayout(null);
        add(panel);

        JLabel label = new JLabel("ADD DRIVERS");
        label.setBounds(130,10,300,40);
        label.setForeground(Color.BLACK);
        label.setFont(new Font("Tahoma", Font.BOLD, 24));
        panel.add(label);
        
        JLabel id = new JLabel("DRIVER ID : ");
        id.setBounds(64,70,102,22);
        id.setFont(new Font("Tahoma", Font.BOLD,14));
        id.setForeground(Color.black);
        panel.add(id);
        DidText = new JTextField();
        DidText.setBounds(174,70,156,20);
        DidText.setForeground(Color.black);
        DidText.setFont(new Font("Tahoma",Font.PLAIN,12));
        DidText.setBackground(Color.WHITE);
        panel.add(DidText);


        JLabel name = new JLabel("NAME :");
        name.setBounds(64,110,102,22);
        name.setFont(new Font("Tahoma", Font.BOLD,14));
        name.setForeground(Color.black);
        panel.add(name);
        nameText = new JTextField();
        nameText.setBounds(176,110,156,20);
        nameText.setForeground(Color.black);
        nameText.setFont(new Font("Tahoma",Font.PLAIN,12));
        nameText.setBackground(Color.WHITE);
        panel.add(nameText);

        JLabel age = new JLabel("AGE :");
        age.setBounds(64,150,102,22);
        age.setFont(new Font("Tahoma", Font.BOLD,14));
        age.setForeground(Color.black);
        panel.add(age);
        ageText = new JTextField();
        ageText.setBounds(174,150,156,20);
        ageText.setForeground(Color.black);
        ageText.setFont(new Font("Tahoma",Font.PLAIN,12));
        ageText.setBackground(Color.WHITE);
        panel.add(ageText);

        JLabel gender = new JLabel("GENDER :");
        gender.setBounds(64,190,110,22);
        gender.setFont(new Font("Tahoma", Font.BOLD,14));
        gender.setForeground(Color.BLACK);
        panel.add(gender);

        comboBox = new JComboBox(new String[]{"Male","Female"});
        comboBox.setBounds(174,190,156,20);
        comboBox.setForeground(Color.BLACK);
        comboBox.setFont(new Font("Tahoma",Font.PLAIN,14));
        comboBox.setBackground(Color.WHITE);
        panel.add(comboBox);
        
        JLabel Mid = new JLabel("MOBILE NO :");
        Mid.setBounds(64,270,102,22);
        Mid.setFont(new Font("Tahoma", Font.BOLD,14));
        Mid.setForeground(Color.black);
        panel.add(Mid);
        MidText = new JTextField();
        MidText.setBounds(174,270,156,20);
        MidText.setForeground(Color.black);
        MidText.setFont(new Font("Tahoma",Font.PLAIN,12));
        MidText.setBackground(Color.WHITE);
        panel.add(MidText);



        JLabel available = new JLabel("AVAILABLE :");
        available.setBounds(64,230,102,22);
        available.setFont(new Font("Tahoma", Font.BOLD,14));
        available.setForeground(Color.BLACK);
        panel.add(available);
        comboBox1 = new JComboBox(new String[]{"YES","NO"});
        comboBox1.setBounds(174,230,156,20);
        comboBox1.setForeground(Color.BLACK);
        comboBox1.setFont(new Font("Tahoma",Font.PLAIN,12));
        comboBox1.setBackground(Color.WHITE);
        panel.add(comboBox1);


        add = new JButton("ADD");
        add.setBounds(64,380,111,33);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        add.addActionListener(this);
        panel.add(add);

        back = new JButton("BACK");
        back.setBounds(198,380,111,33);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        panel.add(back);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("ICONS/driver4.jpg"));
        Image image = imageIcon.getImage().getScaledInstance(350,300,Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel label1 = new JLabel(imageIcon1);
        label1.setBounds(450,100,400,300);
        panel.add(label1);

        setUndecorated(true);
        setLocation(465,150);
        setLayout(null);
        setSize(900,500);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == add){
            String driverid = DidText.getText();            
            String name = nameText.getText();
            String age = ageText.getText();
            String gender = (String) comboBox.getSelectedItem();
            String available =(String) comboBox1.getSelectedItem();
            String mobileno = MidText.getText();
            
             try{
                con c = new con();
                String q = "insert into adddriver values('"+driverid+"','"+name+"','"+age+"', '"+gender+"','"+available+"','"+mobileno+"')";
                c.statement.executeUpdate(q);
                JOptionPane.showMessageDialog(null, "Driver Added");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();
            }

        }else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new addDrivers();
    }
}
