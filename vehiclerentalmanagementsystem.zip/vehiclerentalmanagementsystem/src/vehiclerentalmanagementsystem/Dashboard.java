
package vehiclerentalmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame  implements ActionListener {
    
    JButton rec;
    
    Dashboard(){
        
        super("DASHBOARD");
        
        JPanel panel1 = new JPanel();
        panel1.setLayout(null);
        panel1.setBounds(5,5,270,820);
        panel1.setBackground(Color.white);
        add(panel1);
        
        

       
       
    JLabel text = new JLabel("VEHICAL RENTAL MANAGEMENT SYSTEM ");//making hms visible in screen
    text.setBounds(440, 20, 1000, 50);
    text.setForeground(Color.WHITE);
    text.setFont(new Font("Stencil", Font.BOLD, 46));
    add(text);
        
        ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("ICONS/driver10.jpg"));
        Image i2 = i11.getImage().getScaledInstance(200,120, Image.SCALE_DEFAULT);
        ImageIcon imageIcon11 = new ImageIcon(i2);
        JLabel label1 = new JLabel(imageIcon11);
        label1.setBounds(10,495,200,260);
        panel1.add(label1);

        ImageIcon i111 = new ImageIcon(ClassLoader.getSystemResource("ICONS/carbike.jpeg"));
        Image i22 = i111.getImage().getScaledInstance(200,240, Image.SCALE_DEFAULT);
        ImageIcon imageIcon111 = new ImageIcon(i22);
        JLabel label11 = new JLabel(imageIcon111);
        label11.setBounds(40,270,200,190);
        panel1.add(label11);
        
        ImageIcon i1111 = new ImageIcon(ClassLoader.getSystemResource("ICONS/home6.png"));
        Image i222 = i1111.getImage().getScaledInstance(200,120, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1111 = new ImageIcon(i222);
        JLabel label111 = new JLabel(imageIcon1111);
        label111.setBounds(40,20,190,135);
        panel1.add(label111);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("ICONS/splach.gif"));
        Image i1 = imageIcon.getImage().getScaledInstance(1238,820, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(i1);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(280,0,1238,820);
        add(label);
       
       /* ImageIcon i11 = new ImageIcon(ClassLoader.getSystemResource("ICONS/logo2.jpg"));
        Image i2 = i11.getImage().getScaledInstance(250,250, Image.SCALE_DEFAULT);
        ImageIcon imageIcon11 = new ImageIcon(i2);
        JLabel label1 = new JLabel(imageIcon11);
        label1.setBounds(5,530,250,250);
        panel1.add(label1);*/
 
   
        JButton btnNCF = new JButton("HOME");
        btnNCF.setBounds(60,162,150,35);
        btnNCF.setFont(new Font("Tahoma", Font.BOLD,15));
        btnNCF.setBackground(new Color(255,98,0));
        btnNCF.setForeground(Color.WHITE);
        panel1.add(btnNCF);
        btnNCF.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    setVisible(false);
                    new homescreen();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });
    
        JButton btnRoom = new JButton("ADD VEHICAL");
        btnRoom.setBounds(60,470,150,35);
        btnRoom.setFont(new Font("Tahoma",Font.BOLD,15));
        btnRoom.setBackground(new Color(255,98,0));
        btnRoom.setForeground(Color.WHITE);
        panel1.add(btnRoom);
        btnRoom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new addVehicle();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });
        
        JButton btnDepartment = new JButton("ADD DRIVER");
        btnDepartment.setBounds(60,690,150,35);
        btnDepartment.setBackground(new Color(255,98,0));
        btnDepartment.setFont(new Font("Tahoma", Font.BOLD,15));
        btnDepartment.setForeground(Color.WHITE);
        panel1.add(btnDepartment);
        btnDepartment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new addDrivers();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });
        
       
        setLayout(null);
        setSize(1950,1090);
        setVisible(true);
    }
        
     @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==rec){
           // new homescreen();
            setVisible(false);
        }else {
            new homescreen();
            setVisible(false);
        }
      
    }
    public static void main(String[] args) {
        new Dashboard();
    }
}
       
        