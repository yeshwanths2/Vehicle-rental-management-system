package vehiclerentalmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.mail.*;
import javax.mail.internet.*;

public class vehiclecustomerform extends JFrame implements ActionListener {

    JComboBox comboBox;
    JTextField textFieldNumber, TextName, TextDeposite, TextMail;
    JRadioButton r1, r2;
    Choice c1;
    JLabel date;
    JButton add, back;

    vehiclecustomerform() {

        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 890, 490);
        panel.setLayout(null);
        panel.setBackground(Color.LIGHT_GRAY);
        add(panel);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("ICONS/yyy.jpg"));
        Image image = imageIcon.getImage().getScaledInstance(300, 200, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel imglabel = new JLabel(imageIcon1);
        imglabel.setBounds(500, 100, 350, 200);
        panel.add(imglabel);

        JLabel labelName = new JLabel("CUSTOMER FORM");
        labelName.setBounds(340, 11, 260, 53);
        labelName.setFont(new Font("Tahoma", Font.BOLD, 20));
        labelName.setForeground(Color.black);
        panel.add(labelName);

        JLabel labelID = new JLabel("ID :");
        labelID.setBounds(35, 76, 200, 14);
        labelID.setForeground(Color.black);
        labelID.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelID);

        comboBox = new JComboBox(new String[]{"PASSPORT", "AADHAR CARD", "VOTER ID", "DRIVING LICENSE"});
        comboBox.setBounds(271, 73, 150, 20);
        comboBox.setBackground(Color.white);
        comboBox.setForeground(Color.black);
        comboBox.setFont(new Font("Tahoma", Font.PLAIN, 14));
        panel.add(comboBox);

        JLabel labelNumber = new JLabel("ID NUMBER :");
        labelNumber.setBounds(35, 111, 200, 14);
        labelNumber.setForeground(Color.black);
        labelNumber.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelNumber);
        textFieldNumber = new JTextField();
        textFieldNumber.setBounds(271, 111, 150, 20);
        panel.add(textFieldNumber);

        JLabel labelname = new JLabel("NAME :");
        labelname.setBounds(35, 151, 200, 14);
        labelname.setForeground(Color.black);
        labelname.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelname);
        TextName = new JTextField();
        TextName.setBounds(271, 151, 150, 20);
        panel.add(TextName);

        JLabel labelGender = new JLabel("GENDER :");
        labelGender.setBounds(35, 191, 200, 14);
        labelGender.setForeground(Color.black);
        labelGender.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelGender);

        r1 = new JRadioButton("MALE");
        r1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        r1.setForeground(Color.BLACK);
        r1.setBackground(Color.LIGHT_GRAY);
        r1.setBounds(271, 191, 80, 12);
        panel.add(r1);

        r2 = new JRadioButton("FEMALE");
        r2.setFont(new Font("Tahoma", Font.PLAIN, 14));
        r2.setForeground(Color.BLACK);
        r2.setBackground(Color.LIGHT_GRAY);
        r2.setBounds(350, 191, 120, 12);
        panel.add(r2);

        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(r1);
        genderGroup.add(r2);

        JLabel labelRoom = new JLabel("VEHICLE REG-NO :");
        labelRoom.setBounds(30, 231, 200, 14);
        labelRoom.setForeground(Color.BLACK);
        labelRoom.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelRoom);

        c1 = new Choice();
        try {
            con c = new con();
            ResultSet resultSet = c.statement.executeQuery("select * from vehical2 where status = 'AVAILABLE'");
            while (resultSet.next()) {
                c1.add(resultSet.getString("regno"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        c1.setBounds(271, 231, 150, 20);
        c1.setFont(new Font("Tahoma", Font.PLAIN, 14));
        c1.setForeground(Color.black);
        c1.setBackground(Color.white);
        panel.add(c1);

        JLabel labelCIS = new JLabel("RENT DATE:");
        labelCIS.setBounds(35, 274, 200, 14);
        labelCIS.setForeground(Color.black);
        labelCIS.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelCIS);

        Date date1 = new Date();

        date = new JLabel("" + date1);
        date.setBounds(271, 274, 200, 14);
        date.setForeground(Color.black);
        date.setFont(new Font("Tahoma", Font.PLAIN, 14));
        panel.add(date);

        JLabel labelDeposite = new JLabel("DEPOSIT :");
        labelDeposite.setBounds(35, 316, 200, 14);
        labelDeposite.setForeground(Color.black);
        labelDeposite.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelDeposite);
        TextDeposite = new JTextField();
        TextDeposite.setBounds(271, 316, 150, 20);
        panel.add(TextDeposite);

        JLabel labelMail = new JLabel("MAIL ID :");
        labelMail.setBounds(35, 356, 200, 14);
        labelMail.setForeground(Color.black);
        labelMail.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(labelMail);
        TextMail = new JTextField();
        TextMail.setBounds(271, 356, 150, 20);
        panel.add(TextMail);

        add = new JButton("ADD");
        add.setBounds(100, 430, 120, 30);
        add.setForeground(Color.WHITE);
        add.setBackground(Color.BLACK);
        add.addActionListener(this);
        panel.add(add);

        back = new JButton("BACK");
        back.setBounds(260, 430, 120, 30);
        back.setForeground(Color.WHITE);
        back.setBackground(Color.BLACK);
        back.addActionListener(this);
        panel.add(back);

        setUndecorated(true);
        setLocation(415, 150);
        setLayout(null);
        setSize(900, 500);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == add) {
            con c = new con();
            String radioBtn = null;
            if (r1.isSelected()) {
                radioBtn = "MALE";
            } else if (r2.isSelected()) {
                radioBtn = "FEMALE";
            }

            String id = (String) comboBox.getSelectedItem();
            String idNo = textFieldNumber.getText();
            String name = TextName.getText();
            String gender = radioBtn;
            String regNo = c1.getSelectedItem();
            String rentDate = date.getText();
            String deposite = TextDeposite.getText();
            String mailid = TextMail.getText();

            if (!isValidEmail(mailid)) {
                JOptionPane.showMessageDialog(null, "Invalid Email ID");
                return;
            }

            try {
                String q = "insert into customer0 values ('" + id + "', '" + idNo + "','" + name + "','" + gender + "', '" + regNo + "', '" + rentDate + "', '" + deposite + "', '" + mailid + "')";
                String q1 = "update vehical2 set status = 'Occupied' where regno = '" + regNo + "'";
                c.statement.executeUpdate(q);
                c.statement.executeUpdate(q1);
                JOptionPane.showMessageDialog(null, "Added Successfully");
                sendEmail(mailid, regNo, rentDate, deposite);
                setVisible(false);
            } catch (Exception E) {
                E.printStackTrace();
            }
        } else {
            setVisible(false);
        }
    }

   

    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        if (email == null) return false;
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public void sendEmail(String to, String regNo, String rentDate, String deposit) {
        String from = "yeshwanths2813@gmail.com"; // replace with your email
        String host = "smtp.gmail.com"; // replace with your SMTP server

        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.port", "587");
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.smtp.starttls.enable", "true");

        Session session = Session.getDefaultInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("yeshwanths2813@gmail.com", "euubhpoktclmfwxd"); // replace with your email and password
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject("RENT CONFORMATION");
            message.setText("Thank you for visiting RENT EXPRESS . Hi your vehicle regno " + regNo + " has been booked on " + rentDate + " and you have paid a deposit of " + deposit + ". Have a safe ride.  THANK YOU!");

            Transport.send(message);
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new vehiclecustomerform();
    }
}
